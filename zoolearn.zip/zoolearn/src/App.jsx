import Header from "./header.jsx";
import Banner from "./banner.jsx";
import Footer from "./footer.jsx";
import "./index.css";
import HomePage from "./HomePage.jsx";
import TaxonomyPage from "./TaxonomyPage.jsx";

function App() {
  return (
   <>
    
   </>
      
 
  );
}

export default App;